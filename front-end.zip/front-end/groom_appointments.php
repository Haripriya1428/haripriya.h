<?php
session_start();
include 'config.php';

if (isset($_POST['submit'])) {
    $user_id = $_SESSION['user_id'];
    $pet_name = $_POST['pet_name'];
    $contact_number = $_POST['contact_number'];
    $email = $_POST['email'];
    $appointment_date = $_POST['appointment_date'];
    $service_type = $_POST['service_type'];

    $sql = "INSERT INTO grooming_appointments (user_id, pet_name, contact_number, email, appointment_date, service_type) 
            VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isssss", $user_id, $pet_name, $contact_number, $email, $appointment_date, $service_type);

    if ($stmt->execute()) {
        echo "<script>alert('Grooming appointment booked successfully!'); window.location='user_dashboard.php';</script>";
    } else {
        echo "<script>alert('Error booking grooming appointment');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Book Grooming Appointment</title>
    <style>
        /* General Styles */
body {
    font-family: 'Arial', sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100vh;
}

/* Page Title */
h2 {
    color: #6a1b9a;
    font-size: 26px;
    margin-bottom: 20px;
    text-align: center;
}

/* Form Styling */
form {
    background: white;
    padding: 25px;
    border-radius: 8px;
    box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
    width: 350px;
    display: flex;
    flex-direction: column;
    align-items: center;
}

/* Input Fields */
input {
    width: 90%;
    padding: 12px;
    margin: 8px 0;
    border: 1px solid #ccc;
    border-radius: 6px;
    font-size: 16px;
}

/* Button Styling */
button {
    width: 95%;
    padding: 12px;
    margin-top: 10px;
    background-color: #6a1b9a;
    color: white;
    font-size: 18px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    transition: background 0.3s ease;
}

/* Button Hover Effect */
button:hover {
    background-color: #50136d;
}

/* Responsive Design */
@media screen and (max-width: 400px) {
    form {
        width: 90%;
    }

    input {
        font-size: 14px;
    }
}

    </style>
</head>
<body>
    <h2>Grooming Appointment</h2>
    <form method="POST">
        <input type="text" name="pet_name" placeholder="Pet Name" required>
        <input type="text" name="contact_number" placeholder="Contact Number" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="date" name="appointment_date" required>
        <input type="text" name="service_type" placeholder="Service Type (Bath, Haircut, Nail Trim)" required>
        <button type="submit" name="submit">Book Appointment</button>
    </form>
</body>
</html>
