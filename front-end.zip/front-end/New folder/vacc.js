// Fetch reminders from backend
async function fetchReminders() {
    const response = await fetch('http://127.0.0.1:5000/get_reminders');
    const reminders = await response.json();
  
    const reminderList = document.getElementById('reminder-list');
    const vaccineCounter = document.getElementById('vaccine-counter');
    reminderList.innerHTML = ''; // Clear existing reminders
  
    reminders.forEach((reminder) => {
      const listItem = document.createElement('div');
      listItem.className = 'reminder-item';
      listItem.innerHTML = `
        <span><strong>${reminder.pet_name}</strong> needs <strong>${reminder.vaccine_name}</strong> on <strong>${reminder.vaccination_date}</strong></span>
        <button onclick="deleteReminder('${reminder.pet_name}', '${reminder.vaccine_name}', '${reminder.vaccination_date}')">Remove</button>
      `;
      reminderList.appendChild(listItem);
    });
  
    vaccineCounter.textContent = reminders.length;
  }
  
  // Add reminder to backend
  async function addReminder(petName, vaccineName, vaccinationDate, emailId) {
    const response = await fetch('http://127.0.0.1:5000/add_reminder', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ pet_name: petName, vaccine_name: vaccineName, vaccination_date: vaccinationDate, email_id: emailId })
    });
  
    if (response.ok) {
      alert('Reminder added successfully!');
      fetchReminders();
    } else {
      const error = await response.json();
      alert(error.error);
    }
  }
  
  // Delete reminder from backend
  async function deleteReminder(petName, vaccineName, vaccinationDate) {
    const response = await fetch('http://127.0.0.1:5000/delete_reminder', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ pet_name: petName, vaccine_name: vaccineName, vaccination_date: vaccinationDate })
    });
  
    if (response.ok) {
      alert('Reminder deleted successfully!');
      fetchReminders();
    } else {
      const error = await response.json();
      alert(error.error);
    }
  }
  
  // Event listener for form submission
  document.getElementById('vaccination-form').addEventListener('submit', (event) => {
    event.preventDefault();
  
    const petName = document.getElementById('pet-name').value;
    const vaccineName = document.getElementById('vaccine-name').value;
    const vaccinationDate = document.getElementById('vaccination-date').value;
    const emailId = document.getElementById('email-id').value;
  
    addReminder(petName, vaccineName, vaccinationDate, emailId);
    document.getElementById('vaccination-form').reset();
  });
  
  // Load reminders on page load
  fetchReminders();
  