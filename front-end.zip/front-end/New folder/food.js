// script.js
const healthFoods = [
    { name: "Carrots", img: "images/carrots.jpg", benefits: "Improves eyesight and boosts immunity." },
    { name: "Pumpkin", img: "images/pumpkin.jpg", benefits: "Rich in fiber and beta-carotene." },
    { name: "Blueberries", img: "images/blueberries.jpg", benefits: "Full of antioxidants for brain health." },
    { name: "Chicken", img: "images/chicken.jpg", benefits: "High protein for muscle growth." },
    { name: "Salmon", img: "images/salmon.jpg", benefits: "Omega-3 fatty acids for a healthy coat." },
    { name: "Apples", img: "images/apples.jpg", benefits: "Rich in vitamins and aids digestion." },
    { name: "Spinach", img: "images/spinach.jpg", benefits: "Provides iron and antioxidants." },
    { name: "Sweet Potatoes", img: "images/sweetpotatoes.jpg", benefits: "Rich in fiber and vitamins." },
    { name: "Eggs", img: "images/eggs.jpg", benefits: "Good source of protein and biotin." },
    { name: "Broccoli", img: "images/broccoli.jpg", benefits: "High in fiber and vitamins." },
    { name: "Peas", img: "images/peas.jpg", benefits: "Contains vitamins A, B, and K." },
    { name: "Bananas", img: "images/bananas.jpg", benefits: "Great source of potassium." },
    { name: "Watermelon", img: "images/watermelon.jpg", benefits: "Hydrates and provides antioxidants." },
    { name: "Kale", img: "images/kale.jpg", benefits: "Loaded with fiber and vitamins." },
    { name: "Coconut", img: "images/coconut.jpg", benefits: "Provides healthy fats and fiber." },
    { name: "Beef", img: "images/beef.jpg", benefits: "High protein and iron source." },
    { name: "Zucchini", img: "images/zucchini.jpg", benefits: "Low-calorie and high in fiber." },
    { name: "Green Beans", img: "images/greenbeans.jpg", benefits: "Rich in vitamins and fiber." },
    { name: "Turkey", img: "images/turkey.jpg", benefits: "Low fat and high in protein." },
    { name: "Oranges", img: "images/oranges.jpg", benefits: "High in vitamin C." },
    { name: "Peaches", img: "images/peaches.jpg", benefits: "Rich in fiber and vitamins." },
    { name: "Cabbage", img: "images/cabbage.jpg", benefits: "Boosts digestive health." },
    { name: "Yogurt", img: "images/yogurt.jpg", benefits: "Good for digestive health." },
    { name: "Almonds", img: "images/almonds.jpg", benefits: "Rich in healthy fats." },
    { name: "Chia Seeds", img: "images/chiaseeds.jpg", benefits: "Loaded with omega-3 fatty acids." },
    { name: "Papaya", img: "images/papaya.jpg", benefits: "Aids digestion and boosts immunity." },
    { name: "Mango", img: "images/mango.jpg", benefits: "Rich in vitamins and antioxidants." },
    { name: "Pineapple", img: "images/pineapple.jpg", benefits: "Boosts digestion and immunity." },
    { name: "Avocado", img: "images/avocado.jpg", benefits: "Provides healthy fats and fiber." }
];

const avoidFoods = [
    { name: "Chocolate", img: "images/chocolate.jpg" },
    { name: "Onions", img: "images/onions.jpg" },
    { name: "Garlic", img: "images/garlic.jpg" },
    { name: "Grapes", img: "images/grapes.jpg" },
    { name: "Raisins", img: "images/raisins.jpg" },
    { name: "Avocado", img: "images/avocado.jpg" },
    { name: "Macadamia Nuts", img: "images/macadamia.jpg" },
    { name: "Alcohol", img: "images/alcohol.jpg" },
    { name: "Xylitol", img: "images/xylitol.jpg" },
    { name: "Raw Dough", img: "images/rawdough.jpg" },
    { name: "Fatty Foods", img: "images/fattyfoods.jpg" },
    { name: "Bones", img: "images/bones.jpg" },
    { name: "Caffeine", img: "images/caffeine.jpg" },
    { name: "Salt", img: "images/salt.jpg" },
    { name: "Raw Eggs", img: "images/raweggs.jpg" },
    { name: "Mushrooms", img: "images/mushrooms.jpg" },
    { name: "Tomatoes", img: "images/tomatoes.jpg" },
    { name: "Potatoes", img: "images/potatoes.jpg" },
    { name: "Ice Cream", img: "images/icecream.jpg" },
    { name: "Apple Seeds", img: "images/appleseeds.jpg" },
    { name: "Cherries", img: "images/cherries.jpg" },
    { name: "Peach Pits", img: "images/peachpits.jpg" },
    { name: "Plum Pits", img: "images/plumpits.jpg" },
    { name: "Yeast Dough", img: "images/yeastdough.jpg" },
    { name: "Milk", img: "images/milk.jpg" },
    { name: "Citrus Fruits", img: "images/citrus.jpg" },
    { name: "Fat Trimmings", img: "images/fattrimmings.jpg" },
    { name: "Raw Fish", img: "images/rawfish.jpg" },
    { name: "Sugary Foods", img: "images/sugaryfoods.jpg" },
    { name: "Spicy Foods", img: "images/spicyfoods.jpg" }
];

function showHealthFoods() {
    displayFoods(healthFoods, true);
    document.getElementById("search-container").style.display = "block";
    document.getElementById("main-bg").classList.add("show-bg");
}

function showAvoidFoods() {
    displayFoods(avoidFoods, false);
    document.getElementById("search-container").style.display = "block";
    document.getElementById("main-bg").classList.add("show-bg");
}

function displayFoods(foodList, showBenefits) {
    const foodSection = document.getElementById("food-section");
    foodSection.innerHTML = "";

    foodList.forEach(food => {
        let foodCard = document.createElement("div");
        foodCard.classList.add("food-card");
        foodCard.innerHTML = `
            <img src="${food.img}" alt="${food.name}">
            <h3>${food.name}</h3>
            ${showBenefits && food.benefits ? `<p>${food.benefits}</p>` : ""}
        `;
        foodSection.appendChild(foodCard);
    });
}

function searchFoods() {
    const query = document.getElementById("search-bar").value.toLowerCase();
    const activeList = document.getElementById("food-section").innerHTML.includes("benefits") ? healthFoods : avoidFoods;
    const filteredFoods = activeList.filter(food => food.name.toLowerCase().includes(query));
    displayFoods(filteredFoods, activeList === healthFoods);
}
