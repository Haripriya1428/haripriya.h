function loadPage(page) {
    fetch(page)  // Fetch the HTML file
        .then(response => response.text()) // Convert response to text
        .then(data => {
            document.getElementById('content').innerHTML = data; // Insert content
        })
        .catch(error => console.error('Error loading page:', error));
}