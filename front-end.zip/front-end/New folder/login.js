function showPage(page) {
    document.getElementById('login-form').classList.toggle('show', page === 'login');
    document.getElementById('register-form').classList.toggle('show', page === 'register');
}

function navigateToHome() {
    document.getElementById('login-page').style.display = 'none';
    document.getElementById('home-page').style.display = 'flex';
}
