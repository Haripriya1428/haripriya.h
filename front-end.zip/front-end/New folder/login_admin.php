<?php 
    session_start();
    $connection=mysqli_connect("localhost","root","","vehicle_management"); 
    
    $msg="";
    if(isset($_POST['submit'])){
        $username=mysqli_real_escape_string($connection,strtolower($_POST['username']));
        
        $password=mysqli_real_escape_string($connection,$_POST['password']); 
        
        $login_query="SELECT * FROM `admin` WHERE username='$username' and password='$password'";
        
        $login_res=mysqli_query($connection,$login_query);
        if(mysqli_num_rows($login_res)>0){ 
            $_SESSION['username']=$username;
            header('Location:admin.php');
        } 
        else{
             $msg= '<div class="alert alert-danger alert-dismissable" style="margin-top:30px";>
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                    <strong>Unsuccessful!</strong> Login Unsuccessful.
                  </div>';
        }
    }

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sign Up</title> 
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> 
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <link rel="stylesheet" href="animate.css">
    <link rel="stylesheet" href="style.css">
    <style>
    body, html {
    height: 100%;
    margin: 0;
    font-family: 'Arial', sans-serif;
    scroll-behavior: smooth;
    background-color:rgb(75, 53, 80);
}

.bg {
    background-image: url('pexels-photo-808156.jpeg');
    height: 100%;
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
    filter: brightness(90%);
}

.jumbotron {
    background: linear-gradient(to right, #ff9a9e, #fad0c4);
    padding: 40px;
    text-align: center;
    border-radius: 10px;
    box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
}

.jumbotron h2 {
    color: #fff;
    font-weight: bold;
    animation: bounce 2s;
}

.jumbotron p {
    font-size: 18px;
    color: #fff;
}

.parallax {
    background-image: url('bus-people-public-transportation-34171.jpg');
    min-height: 700px;
    background-attachment: fixed;
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
    filter: brightness(85%);
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
    text-align: center;
}

.parallax1 {
    background-image: url('pexels-photo-280310.jpeg');
    min-height: 600px;
    background-attachment: fixed;
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
    filter: brightness(90%);
}

.hero-text {
    font-size: 50px;
    text-align: center;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    color: white;
    text-shadow: 3px 3px 10px rgba(0, 0, 0, 0.6);
}

.navbar-fixed-top.scrolled {
    background: linear-gradient(to right, #ff758c, #ff7eb3);
    transition: background-color 300ms ease-in-out;
    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.2);
}

.container {
    padding: 20px;
}

.page-header {
    text-align: center;
    padding-bottom: 20px;
    color: #444;
}

.img-responsive {
    width: 100%;
    border-radius: 10px;
    box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.3);
}

footer {
    background: linear-gradient(to right, #232526, #414345);
    color: #fff;
    padding: 70px 0;
    text-align: center;
}

.btn-success {
    font-size: 18px;
    padding: 10px 20px;
    transition: all 0.3s ease-in-out;
    background: linear-gradient(to right, #00b09b, #96c93d);
    border: none;
    color: white;
}

.btn-success:hover {
    background: linear-gradient(to right, #ff416c, #ff4b2b);
    color: white;
}
</style>

</head>
<body> 
  <?php include 'navbar.php'; ?>
   
    
    <br>
    <div class="container"> 
     <div class="row">
       <div class="col-md-3"></div>
        <div class="col-md-6"> 
          <?php echo $msg; ?>
            <div class="page-header">
                <h1 style="text-align: center;">Admin Login</h1>      
          </div> 
            <form class="form-horizontal animated bounce" action="" method="post"> 
                <div class="input-group">
                  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                  <input id="username" type="text" class="form-control" name="username" placeholder="Username">
                </div>
                <br>
                
                <div class="input-group">
                  <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                  <input id="password" type="password" class="form-control" name="password" placeholder="Password">
                </div>
                <br> 
                
                <div class="input-group">
                  <button type="submit" name="submit" class="btn btn-success">Log in</button>
                  
                </div>

              </form>   
        </div> 
        <div class="col-md-3"></div>
         
     </div>
         
   
    </div> 
    
   
    
</body>
</html>