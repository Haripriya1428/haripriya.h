// Define a list of hospitals
const hospitals = [
    { name: 'Paws & Claws Veterinary', address: '123 Pet Street', phone: '(123) 456-7890', img: 'hos1.jpg', petImage: 'hos1.jpg' },
    { name: 'Whiskers & Tails Animal Clinic', address: '456 Kitty Road', phone: '(987) 654-3210', img: 'hos2.jpg', petImage: 'hos2.jpg' },
    { name: 'Bark Park Veterinary', address: '789 Dog Avenue', phone: '(555) 123-4567', img: 'hos3.jpg', petImage: 'hos3.jpg' },
    { name: 'Furry Friends Veterinary', address: '1010 Animal Blvd', phone: '(888) 555-4321', img: 'hos4.jpg', petImage: 'hos4.jpg' },
    { name: 'Happy Tails Clinic', address: '2020 Pet Ln', phone: '(777) 444-1234', img: 'hos5.jpg', petImage: 'hos5.jpg' }
];

// Function to render hospitals
function renderHospitals() {
    const hospitalList = document.getElementById('hospitalList');
    hospitalList.innerHTML = '';

    hospitals.forEach((hospital) => {
        const hospitalCard = document.createElement('div');
        hospitalCard.classList.add('hospital-card');
        hospitalCard.innerHTML = `
            <img src="${hospital.img}" alt="${hospital.name}">
            <div class="hospital-name">🐶 ${hospital.name}</div>
            <div class="hospital-address">📍 ${hospital.address}</div>
            <div class="hospital-phone">📞 ${hospital.phone}</div>
            <button onclick="showAppointmentForm('${hospital.petImage}')">💖 Book Appointment</button>
        `;
        
        hospitalList.appendChild(hospitalCard);
    });
}

// Function to show appointment form
function showAppointmentForm(petImage) {
    document.getElementById('hospitalListSection').style.display = 'none';
    document.getElementById('appointmentFormSection').style.display = 'block';
    document.getElementById('selectedPetImage').src = petImage;
}

// Handle appointment form submission
document.getElementById('appointmentForm').addEventListener('submit', function (e) {
    e.preventDefault();
    
    // Get form values
    const petName = document.getElementById('petName').value;
    const ownerName = document.getElementById('ownerName').value;
    const contactInfo = document.getElementById('contactInfo').value;
    const appointmentDate = document.getElementById('appointmentDate').value;

    // Show confirmation message
    if (petName && ownerName && contactInfo && appointmentDate) {
        document.getElementById('confirmationMessage').innerText = `🎉 Appointment booked successfully for ${petName}!`;
    }
});

// Initial render
renderHospitals();
