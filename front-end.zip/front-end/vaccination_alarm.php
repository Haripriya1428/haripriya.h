<?php
include 'config.php';

$today = date('Y-m-d');
$tomorrow = date('Y-m-d', strtotime('+1 day'));

$sql = "SELECT u.email, v.vaccine_name, v.vaccination_date 
        FROM vaccinations v 
        JOIN users u ON v.user_id = u.id 
        WHERE v.vaccination_date IN (?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $today, $tomorrow);
$stmt->execute();
$result = $stmt->get_result();

$reminders = [];

while ($row = $result->fetch_assoc()) {
    $reminders[] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Vaccination Reminder</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">
    <h1>🐾 Vaccination Reminders</h1>

    <?php if (!empty($reminders)): ?>
        <audio id="alarm-sound" autoplay>
            <source src="alarm.mp3" type="audio/mpeg">
        </audio>
        <script>
            // Play alarm sound when the page loads
            document.getElementById("alarm-sound").play();
            alert("⚠️ Vaccination reminder alert! Check the list below.");
        </script>
        <ul>
            <?php foreach ($reminders as $reminder): ?>
                <li>
                    <strong><?= $reminder['email'] ?></strong> - 
                    Vaccine: <strong><?= $reminder['vaccine_name'] ?></strong> - 
                    Date: <strong><?= $reminder['vaccination_date'] ?></strong>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php else: ?>
        <p>No vaccination reminders for today or tomorrow.</p>
    <?php endif; ?>
</div>

</body>
</html>
