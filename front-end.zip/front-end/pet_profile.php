<?php
session_start();
include "config.php";

if (isset($_POST['save'])) {
    $pet_name = $_POST['pet_name'];
    $pet_breed = $_POST['pet_breed'];
    $pet_age = $_POST['pet_age'];
    $pet_weight = $_POST['pet_weight'];

    $sql = "INSERT INTO pets (pet_name, pet_breed, pet_age, pet_weight) VALUES ('$pet_name', '$pet_breed', '$pet_age', '$pet_weight')";
    
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Pet profile saved successfully!');</script>";
    } else {
        echo "<script>alert('Error: " . $conn->error . "');</script>";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Pet Profile</title>
    <link rel="stylesheet" href="style.css">
    <style>
    /* General Styles */
body {
    font-family: Arial, sans-serif;
    background-color: #f5e1ff; /* Light Purple */
    margin: 0;
    padding: 0;
    text-align: center;
}

/* Container Styling */
.container {
    background: #ffffff;
    width: 40%;
    margin: 50px auto;
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
    border-top: 5px solid #6a0dad; /* Dark Purple Border */
}

/* Heading */
h1 {
    color: #4b0082; /* Deep Purple */
}

/* Form Styling */
form {
    display: flex;
    flex-direction: column;
    align-items: center;
}

/* Input Fields */
input {
    width: 80%;
    padding: 10px;
    margin: 8px 0;
    border: 2px solid #6a0dad;
    border-radius: 8px;
    outline: none;
    font-size: 16px;
}

input:focus {
    border-color: #4b0082;
}

/* Button */
button {
    background: #6a0dad;
    color: white;
    border: none;
    padding: 12px 20px;
    font-size: 16px;
    border-radius: 8px;
    cursor: pointer;
    transition: 0.3s;
}

button:hover {
    background: #4b0082;
}

/* Circular Pet Image Preview */
#pet-image {
    width: 150px;
    height: 150px;
    border-radius: 50%;
    border: 4px solid #6a0dad;
    object-fit: cover;
    margin-top: 10px;
}

/* Upload Button */
input[type="file"] {
    margin: 10px 0;
}

    </style>
</head>
<body >
<?php include 'user_navbar.html'; ?>

<div class="container">
    <h1>🐶 Pet Profile</h1>
    <form method="POST">
        <input type="text" name="pet_name" placeholder="🐾 Pet Name" required>
        <input type="text" name="pet_breed" placeholder="🐕 Breed" required>
        <input type="number" name="pet_age" placeholder="🎂 Age" required>
        <input type="text" name="pet_weight" placeholder="⚖️ Weight" required>
        <input type="file" id="upload-image" accept="image/*">
<img id="pet-image" src="default-pet.png" alt="Pet Preview">

        <button type="submit" name="save">Save Profile</button>
    </form>
</div>
<script>
    // Function to toggle menu visibility
function toggleMenu() {
    document.getElementById("menu-options").classList.toggle("show");
}

// Function to preview uploaded pet images

document.addEventListener("DOMContentLoaded", function () {
    let uploadInput = document.getElementById("upload-image");
    uploadInput.addEventListener("change", function (event) {
        var reader = new FileReader();
        reader.onload = function () {
            document.getElementById("pet-image").src = reader.result;
        };
        reader.readAsDataURL(event.target.files[0]);
    });
});


</script>
</body>
</html>
