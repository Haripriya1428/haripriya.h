<?php
include 'config.php';
$msg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

    $query = "INSERT INTO users (username, email, password) VALUES ('$username', '$email', '$password')";
    
    if (mysqli_query($conn, $query)) {
        $msg = "Registration successful! <a href='login.php'>Login Here</a>";
    } else {
        $msg = "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Register</title>
    <link rel="stylesheet" href="style.css">
    <style>
   /* Import Google Font */
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap');

/* General Styles */
body {
    font-family: 'Poppins', sans-serif;
    background: url('image/dog7.jpg') no-repeat center center fixed;
    background-size: cover;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
    position: relative;
}

/* Dark overlay */
body::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(75, 0, 130, 0.6); /* Purple overlay */
    z-index: 1;
}

/* Form Container */
.form-container {
    position: relative;
    z-index: 2;
    background: rgba(255, 255, 255, 0.95);
    padding: 25px;
    border-radius: 10px;
    box-shadow: 0px 5px 10px rgba(0, 0, 0, 0.3);
    width: 360px;
    text-align: center;
    animation: fadeIn 0.8s ease-in-out;
}

/* Form Title */
h2 {
    color: #6a0dad;
    margin-bottom: 15px;
}

/* Input Fields */
input {
    width: 100%;
    padding: 12px;
    margin: 10px 0;
    border: 1px solid #ccc;
    border-radius: 6px;
    font-size: 16px;
    transition: 0.3s;
}

/* Input Focus Effect */
input:focus {
    border-color: #6a0dad;
    box-shadow: 0px 0px 8px rgba(106, 13, 173, 0.5);
    outline: none;
}

/* Buttons */
button {
    background-color: #6a0dad;
    color: white;
    padding: 12px;
    width: 100%;
    border: none;
    border-radius: 6px;
    font-size: 18px;
    cursor: pointer;
    transition: 0.3s ease;
}

button:hover {
    background-color: #4b0082;
}

/* Message Styling */
p {
    color: #333;
    font-size: 14px;
}

/* Success & Error Message Styling */
.success {
    color: green;
    font-weight: bold;
}

.error {
    color: red;
    font-weight: bold;
}

/* Links */
a {
    color: #6a0dad;
    text-decoration: none;
    font-weight: bold;
    transition: 0.3s;
}

a:hover {
    color: #4b0082;
}

/* Animation */
@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(-20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

/* Responsive Design */
@media (max-width: 400px) {
    .form-container {
        width: 90%;
    }
}


    </style>
</head>
<body>


    <div class="form-container">
        <h2>Register</h2>
        <p><?php echo $msg; ?></p>
        <form action="" method="POST">
            <input type="text" name="username" placeholder="Username" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Register</button>
        </form>
        <p>Already have an account? <a href="login.php">Login</a></p>
    </div>
</body>
</html>
