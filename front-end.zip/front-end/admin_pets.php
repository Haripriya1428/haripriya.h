<?php
session_start();
include "config.php";

$sql = "SELECT * FROM pets";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin - Pet Profiles</title>
   <style>
    /* General Styles */
body {
    margin: 0;
    padding: 0;
    font-family: 'Arial', sans-serif;
    background-color: #f9f9f9;
    color: #333;
}

/* Container */
.container {
    width: 80%;
    margin: 50px auto;
    background: white;
    padding: 20px;
    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
    text-align: center;
}

/* Heading */
h1 {
    font-size: 26px;
    color: #6a1b9a;
    margin-bottom: 20px;
}

/* Table Styles */
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
    background: white;
    border-radius: 8px;
    overflow: hidden;
}

/* Table Headers */
th {
    background: #6a1b9a;
    color: white;
    padding: 12px;
    font-size: 16px;
    text-transform: uppercase;
}

/* Table Rows */
td {
    padding: 12px;
    font-size: 15px;
    border-bottom: 1px solid #ddd;
}

/* Alternating Row Colors */
tr:nth-child(even) {
    background: #f2f2f2;
}

/* Hover Effect */
tr:hover {
    background: rgba(106, 27, 154, 0.2);
}

/* Responsive Design */
@media screen and (max-width: 768px) {
    .container {
        width: 95%;
        padding: 15px;
    }

    table {
        font-size: 14px;
    }

    th, td {
        padding: 10px;
    }
}

   </style>
</head>
<body>
<?php include 'admin_navbar.html'; ?>
<div class="container">
    <h1>🐾 Pet Profiles</h1>
    <table border="1">
        <tr>
            <th>Pet Name</th>
            <th>Breed</th>
            <th>Age</th>
            <th>Weight</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()) { ?>
        <tr>
            <td><?php echo $row['pet_name']; ?></td>
            <td><?php echo $row['pet_breed']; ?></td>
            <td><?php echo $row['pet_age']; ?></td>
            <td><?php echo $row['pet_weight']; ?></td>
        </tr>
        <?php } ?>
    </table>
</div>
<script>
    // Function to toggle menu visibility
function toggleMenu() {
    document.getElementById("menu-options").classList.toggle("show");
}

// Function to preview uploaded pet images
document.addEventListener("DOMContentLoaded", function () {
    let uploadInput = document.getElementById("upload-image");
    if (uploadInput) {
        uploadInput.addEventListener("change", function (event) {
            var reader = new FileReader();
            reader.onload = function () {
                document.getElementById("pet-image").src = reader.result;
            };
            reader.readAsDataURL(event.target.files[0]);
        });
    }
});

</script>

</body>
</html>
