<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <style>
        /* General Styling */
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background: linear-gradient(to right, #6a0572, #d90429);
    color: #fff;
}

/* Sidebar Navigation */
.sidebar {
    width: 250px;
    height: 100vh;
    position: fixed;
    background: url('images/sidebar-bg.jpg') no-repeat center center/cover;
    padding-top: 20px;
}

.sidebar h2 {
    text-align: center;
    color: #fff;
    font-size: 24px;
}

.sidebar a {
    display: block;
    color: #fff;
    padding: 15px;
    text-decoration: none;
    font-size: 18px;
    transition: 0.3s;
}

.sidebar a i {
    margin-right: 10px;
}

.sidebar a:hover {
    background: #d90429;
    transform: scale(1.1);
}

/* Main Content */
.content {
    margin-left: 270px;
    padding: 20px;
}

h1 {
    font-size: 36px;
}

/* Dashboard Cards */
.dashboard {
    display: flex;
    gap: 20px;
    margin-top: 20px;
}

.card {
    background: rgba(255, 255, 255, 0.2);
    padding: 20px;
    width: 300px;
    text-align: center;
    border-radius: 10px;
    position: relative;
    overflow: hidden;
}

.card-img {
    width: 100%;
    height: 150px;
    object-fit: cover;
    border-radius: 10px;
}

.card h3 {
    font-size: 24px;
    margin-top: 15px;
}

.btn {
    display: inline-block;
    margin-top: 10px;
    padding: 10px 15px;
    background: #d90429;
    color: #fff;
    text-decoration: none;
    border-radius: 5px;
    transition: 0.3s;
}

.btn:hover {
    background: #a0021e;
    transform: scale(1.1);
}

    </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <h2>Admin Panel</h2>
    <a href="admin_dashboard.php"><i class="fas fa-home"></i> Dashboard</a>
    <a href="admin_hospital.php"><i class="fas fa-hospital"></i> Hospital Appointments</a>
    <a href="admin_groom_appointments.php"><i class="fas fa-cut"></i> Grooming Appointments</a>
    <a href="admin_vaccination.php"><i class="fas fa-cut"></i> vaccination</a>
    <a href="admin_pets.php"><i class="fas fa-cut"></i> About pet</a>
    <a href="admin_regester.php"><i class="fas fa-cut"></i> about_user</a>
    <a href="admin_logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</div>

<!-- Main Content -->
<div class="content">
    <h1>Welcome, Admin</h1>
    <p>Manage hospital and grooming appointments efficiently.</p>

    <div class="dashboard">
        <div class="card">
            <img src="image/hospital_imge2.jpeg" alt="Hospital" class="card-img">
            <h3>Hospital Appointments</h3>
            <p>Manage pet medical appointments.</p>
            <a href="admin_hospital.php" class="btn">View</a>
        </div>
        <div class="card">
            <img src="image/groom_img3.jpeg" alt="Grooming" class="card-img">
            <h3>Grooming Appointments</h3>
            <p>Handle grooming schedules.</p>
            <a href="admin_groom_appointments.php" class="btn">View</a>
        </div>
        <div class="card">
            <img src="image/dog5.jpg" alt="Grooming" class="card-img">
            <h3> Vaccination Appointments</h3>
            <p>Handle vaccination schedules.</p>
            <a href="admin_vaccination.php" class="btn">View</a>
        </div>
        <div class="card">
            <img src="image/pet_img4.jpeg" alt="Grooming" class="card-img">
            <h3>PetProfile</h3>
            <p>The User PET profile</p>
            <a href="admin_pets.php" class="btn">View</a>
        </div>
        <div class="card">
            <img src="image/admin_img.jpeg" alt="Grooming" class="card-img">
            <h3>USER</h3>
            <p>About User Details</p>
            <a href="view_users.php" class="btn">View</a>
        </div>
    </div>
</div>

</body>
</html>
