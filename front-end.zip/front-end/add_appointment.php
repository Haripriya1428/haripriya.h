<?php
session_start();
include 'config.php'; // Database connection

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['user_id'];
    $pet_name = $_POST['pet_name'];
    $appointment_date = $_POST['appointment_date'];

    $sql = "INSERT INTO appointments (user_id, pet_name, appointment_date) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iss", $user_id, $pet_name, $appointment_date);

    if ($stmt->execute()) {
        echo "Appointment added successfully! <a href='user_dashboard.php'>Go Back</a>";
    } else {
        echo "Error adding appointment!";
    }
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Add Appointment</title>
    <style>
    body {
    background: url('your-new-image.jpg') no-repeat center center fixed;
    background-size: cover;
    font-family: 'Verdana', sans-serif;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
    color: white;
}

h2 {
    color: #6a0dad; /* Darker Purple */
    text-align: center;
}

form {
    background: rgba(102, 0, 102, 0.9); /* Dark Purple with transparency */
    padding: 25px;
    border-radius: 12px;
    box-shadow: 0 0 15px rgba(0, 0, 0, 0.6);
    width: 320px;
}

label {
    display: block;
    margin: 12px 0 6px;
    font-weight: bold;
}

input[type="text"], input[type="date"] {
    width: 100%;
    padding: 10px;
    margin-bottom: 12px;
    border: 2px solid #800080; /* Purple border */
    border-radius: 6px;
    background: #f8f8f8;
}

button {
    background-color: #e60000; /* Bright Red */
    color: white;
    padding: 12px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    width: 100%;
    font-size: 18px;
    transition: background 0.3s;
}

button:hover {
    background-color: #b30000;
}


    </style>
</head>
<body>
    <form method="POST">
        <label>Pet Name:</label>
        <input type="text" name="pet_name" required>
        <label>Appointment Date:</label>
        <input type="date" name="appointment_date" required>
        <button type="submit">Add Appointment</button>
    </form>
</body>
</html>
