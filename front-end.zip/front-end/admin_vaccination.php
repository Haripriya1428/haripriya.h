<?php
include 'config.php'; // Database connection
session_start();

// Check if admin is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location:admin_login.php");
    exit();
}

$message = "";

// Handle approval/rejection
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $vaccination_id = $_POST['vaccination_id'];
    $status = $_POST['status'];

    $updateQuery = "UPDATE vaccinations SET status='$status' WHERE id='$vaccination_id'";
    
    if (mysqli_query($conn, $updateQuery)) {
        $message = "Vaccination status updated successfully!";
    } else {
        $message = "Error: " . mysqli_error($conn);
    }
}

// Fetch all vaccination requests
$query = "SELECT v.id, u.username, v.vaccine_name, v.vaccination_date, v.status 
          FROM vaccinations v
          JOIN users u ON v.user_id = u.id
          ORDER BY v.vaccination_date ASC";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin - Approve Vaccinations</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('image/admin-bg.jpg') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            position: relative;
            width: 80%;
            max-width: 900px;
            background: rgba(255, 255, 255, 0.9);
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.3);
            text-align: center;
        }

        h2 {
            color: #4b0082;
        }

        .message {
            color: green;
            font-weight: bold;
            margin-bottom: 10px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: center;
        }

        th {
            background: #6a0dad;
            color: white;
        }

        tr:nth-child(even) {
            background: #f2f2f2;
        }

        .btn {
            padding: 8px 12px;
            margin: 5px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }

        .approve { background: green; color: white; }
        .reject { background: red; color: white; }
    </style>
</head>
<body>

<div class="container">
    <h2>Manage Vaccination Requests</h2>

    <?php if ($message): ?>
        <p class="message"><?php echo $message; ?></p>
    <?php endif; ?>

    <table>
        <tr>
            <th>Username</th>
            <th>Vaccine Name</th>
            <th>Vaccination Date</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
        <tr>
            <td><?php echo $row['username']; ?></td>
            <td><?php echo $row['vaccine_name']; ?></td>
            <td><?php echo $row['vaccination_date']; ?></td>
            <td><?php echo $row['status']; ?></td>
            <td>
                <form method="POST">
                    <input type="hidden" name="vaccination_id" value="<?php echo $row['id']; ?>">
                    <button class="btn approve" name="status" value="Approved">Approve</button>
                    <button class="btn reject" name="status" value="Rejected">Reject</button>
                </form>
            </td>
        </tr>
        <?php } ?>
    </table>
</div>

</body>
</html>
