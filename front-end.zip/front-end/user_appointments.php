<?php
include 'config.php';
session_start();

// Assuming the user is logged in and session stores user ID
$user_id = $_SESSION['user_id'];

$result = $conn->prepare("SELECT pet_name, appointment_date, reason, status FROM hospital_appointments WHERE user_id = ?");
$result->bind_param("i", $user_id);
$result->execute();
$result->bind_result($pet_name, $appointment_date, $reason, $status);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Hospital Appointments</title>
    <link rel="stylesheet" href="styles.css"> <!-- Add your CSS file -->
</head>
<body>
    <?php include 'user_navbar.html'; ?> <!-- User Navigation -->
    
    <h2>My Hospital Appointments</h2>
    <table border='1'>
        <tr>
            <th>Pet Name</th>
            <th>Appointment Date</th>
            <th>Reason</th>
            <th>Status</th>
        </tr>
        <?php while ($result->fetch()) { ?>
            <tr>
                <td><?= htmlspecialchars($pet_name) ?></td>
                <td><?= htmlspecialchars($appointment_date) ?></td>
                <td><?= htmlspecialchars($reason) ?></td>
                <td>
                    <?php if ($status == "Approved") { ?>
                        <span style="color: green; font-weight: bold;">✅ Approved</span>
                    <?php } elseif ($status == "Rejected") { ?>
                        <span style="color: red; font-weight: bold;">❌ Rejected</span>
                    <?php } else { ?>
                        <span style="color: orange; font-weight: bold;">⏳ Pending</span>
                    <?php } ?>
                </td>
            </tr>
        <?php } ?>
    </table>
</body>
</html>

<?php
$result->close();
?>
