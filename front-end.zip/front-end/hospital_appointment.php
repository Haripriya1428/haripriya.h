<?php
include 'config.php';

if (isset($_POST['submit'])) {
    $user_id = $_SESSION['user_id'];
    $pet_name = $_POST['pet_name'];
    $appointment_date = $_POST['appointment_date'];
    $reason = $_POST['reason'];
    $contact_number = $_POST['contact_number'];
    $email = $_POST['email'];

    $sql = "INSERT INTO hospital_appointments (user_id, pet_name, appointment_date, reason, contact_number, email, status) 
            VALUES (?, ?, ?, ?, ?, ?, 'Pending')";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isssss", $user_id, $pet_name, $appointment_date, $reason, $contact_number, $email);
    
    if ($stmt->execute()) {
        echo "<script>alert('Appointment booked successfully!'); window.location='dashboard.php';</script>";
    } else {
        echo "<script>alert('Error booking appointment');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Book Hospital Appointment</title>
  <style>
    /* General Styles */
body {
    font-family: 'Arial', sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100vh;
}

/* Container Styling */
.container {
    background: white;
    padding: 25px;
    border-radius: 8px;
    box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
    width: 380px;
    display: flex;
    flex-direction: column;
    align-items: center;
}

/* Page Title */
h2 {
    color: #6a1b9a;
    font-size: 24px;
    margin-bottom: 20px;
    text-align: center;
}

/* Input Fields */
input, textarea {
    width: 90%;
    padding: 12px;
    margin: 8px 0;
    border: 1px solid #ccc;
    border-radius: 6px;
    font-size: 16px;
}

/* Textarea Styling */
textarea {
    resize: none;
    height: 100px;
}

/* Button Styling */
button {
    width: 95%;
    padding: 12px;
    margin-top: 10px;
    background-color: #6a1b9a;
    color: white;
    font-size: 18px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    transition: background 0.3s ease;
}

/* Button Hover Effect */
button:hover {
    background-color: #50136d;
}

/* Responsive Design */
@media screen and (max-width: 400px) {
    .container {
        width: 90%;
    }

    input, textarea {
        font-size: 14px;
    }
}

  </style>
</head>
<body>
<?php include 'user_navbar.html'; ?>
<div class="container">
    <h2>Book Hospital Appointment</h2>
    <form method="POST">
        <input type="text" name="pet_name" placeholder="Pet Name" required>
        <input type="date" name="appointment_date" required>
        <textarea name="reason" placeholder="Reason for Visit" required></textarea>
        <input type="text" name="contact_number" placeholder="Contact Number" required>
        <input type="email" name="email" placeholder="Email" required>
        <button type="submit" name="submit">Book Appointment</button>
    </form>
</div>
</body>
</html>
