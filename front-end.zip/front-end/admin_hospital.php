<?php
include 'config.php';
$result = $conn->query("SELECT * FROM hospital_appointments");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Hospital Appointments</title>
 <style>
    /* General Page Styling */
body {
    font-family: 'Arial', sans-serif;
    background: #f4f4f9;
    margin: 0;
    padding: 20px;
    text-align: center;
}

/* Navbar Styling */
nav {
    background: #6a1b9a;
    padding: 10px;
    text-align: center;
}

nav a {
    color: white;
    text-decoration: none;
    font-size: 18px;
    padding: 10px 20px;
}

nav a:hover {
    background: #4a148c;
    border-radius: 5px;
}

/* Page Title */
h2 {
    color: #4a148c;
    font-size: 28px;
    margin-bottom: 20px;
}

/* Table Styling */
table {
    width: 90%;
    max-width: 1000px;
    margin: 0 auto;
    border-collapse: collapse;
    background: white;
    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
    border-radius: 10px;
    overflow: hidden;
}

/* Table Header */
th {
    background: #6a1b9a;
    color: white;
    padding: 12px;
    font-size: 18px;
    text-align: center;
}

/* Table Rows */
td {
    padding: 10px;
    text-align: center;
    font-size: 16px;
    border-bottom: 1px solid #ddd;
}

/* Alternate Row Colors */
tr:nth-child(even) {
    background: #f8f8f8;
}

/* Hover Effect */
tr:hover {
    background: #e1bee7;
    transition: 0.3s;
}

/* Action Buttons */
a {
    text-decoration: none;
    font-weight: bold;
    padding: 5px 12px;
    border-radius: 5px;
    transition: 0.3s;
}

/* Approve Button */
a.approve {
    background: #2e7d32;
    color: white;
}

a.approve:hover {
    background: #1b5e20;
}

/* Reject Button */
a.reject {
    background: #c62828;
    color: white;
}

a.reject:hover {
    background: #b71c1c;
}

 </style>
</head>
<body>
<?php include 'admin_navbar.html'; ?>
    <h2>Hospital Appointments</h2>
    <table border='1'>
        <tr>
            <th>ID</th><th>User ID</th><th>Pet Name</th><th>Date</th><th>Reason</th><th>Contact</th><th>Email</th><th>Status</th><th>Action</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()) { ?>
            <tr>
                <td><?= $row['id'] ?></td>
                <td><?= $row['user_id'] ?></td>
                <td><?= $row['pet_name'] ?></td>
                <td><?= $row['appointment_date'] ?></td>
                <td><?= $row['reason'] ?></td>
                <td><?= $row['contact_number'] ?></td>
                <td><?= $row['email'] ?></td>
                <td><?= $row['status'] ?></td>
                <td>
                    <a href="approve.php?id=<?= $row['id'] ?>&status=Approved">Approve</a>
                    <a href="approve.php?id=<?= $row['id'] ?>&status=Rejected">Reject</a>
                </td>
            </tr>
        <?php } ?>
    </table>
</body>
</html>