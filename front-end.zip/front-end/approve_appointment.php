<?php
include 'config.php';

// Check if id and status are set
if (isset($_GET['id']) && isset($_GET['status'])) {
    $id = $_GET['id'];
    $status = $_GET['status'];

    // Fetch user email from the database
    $query = "SELECT email FROM hospital_appointments WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->bind_result($email);
    $stmt->fetch();
    $stmt->close();

    if ($email) {
        // Update appointment status
        $update_sql = "UPDATE hospital_appointments SET status = ? WHERE id = ?";
        $stmt = $conn->prepare($update_sql);
        $stmt->bind_param("si", $status, $id);

        if ($stmt->execute()) {
            // Send email to the user
            $subject = "Hospital Appointment Status Update";
            $message = "Dear User,\n\nYour hospital appointment status has been updated to: $status.\n\nThank you!";
            $headers = "From: admin@petcare.com";

            mail($email, $subject, $message, $headers);

            echo "<script>alert('Appointment status updated and email sent!'); window.location='admin_hospital.php';</script>";
        } else {
            echo "<script>alert('Error updating status');</script>";
        }
    } else {
        echo "<script>alert('User email not found');</script>";
    }
} else {
    echo "<script>alert('Invalid request');</script>";
}
?>
