<?php
include 'config.php'; // Database connection

// Get tomorrow's and today's date
$tomorrow = date('Y-m-d', strtotime('+1 day'));
$today = date('Y-m-d');

// Fetch appointments for tomorrow and today
$sql = "SELECT * FROM appointments WHERE (appointment_date = ? OR appointment_date = ?) AND notification_sent = 0";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $tomorrow, $today);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $to = $row['email'];
    $subject = "Appointment Reminder for {$row['pet_name']}";
    $message = "Hello,\n\nReminder: Your appointment for {$row['pet_name']} is on {$row['appointment_date']}.\n\nRegards, Pet Care System.";
    $headers = "From: no-reply@petcare.com";

    if (mail($to, $subject, $message, $headers)) {
        // Update notification status
        $update_sql = "UPDATE appointments SET notification_sent = 1 WHERE id = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("i", $row['id']);
        $update_stmt->execute();
    }
}

$stmt->close();
$conn->close();
?>
