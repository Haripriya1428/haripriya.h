<!DOCTYPE html>
<html lang="en">
<head>
    <title>User - Submit Vaccination</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('image/user-bg.jpg') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            width: 80%;
            max-width: 700px;
            background: rgba(255, 255, 255, 0.95);
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.3);
            text-align: center;
        }

        h2 {
            color: #4b0082;
        }

        .message {
            font-weight: bold;
            margin-bottom: 10px;
            padding: 10px;
            border-radius: 5px;
            background-color: #f8f9fa;
        }

        .message.success {
            color: green;
            background-color: #e9f7ef;
        }

        .message.error {
            color: red;
            background-color: #f8d7da;
        }

        input {
            width: 90%;
            padding: 10px;
            margin: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        button {
            background-color: #6a0dad;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: 0.3s;
        }

        button:hover {
            background-color: #4b0082;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: center;
        }

        th {
            background: #6a0dad;
            color: white;
        }

        tr:nth-child(even) {
            background: #f2f2f2;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Submit Your Vaccination Details</h2>

    <?php if ($message): ?>
        <p class="message <?= strpos($message, '✅') !== false ? 'success' : 'error' ?>">
            <?php echo $message; ?>
        </p>
    <?php endif; ?>

    <form action="" method="POST" onsubmit="return validateForm()">
        <input type="text" name="vaccine_name" id="vaccine_name" placeholder="Vaccine Name" required>
        <input type="date" name="vaccination_date" id="vaccination_date" required>
        <button type="submit">Submit Vaccination</button>
    </form>

    <h3>My Submitted Vaccination Records</h3>
    <table>
        <tr>
            <th>Vaccine Name</th>
            <th>Vaccination Date</th>
            <th>Status</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()) { ?>
        <tr>
            <td><?php echo htmlspecialchars($row['vaccine_name']); ?></td>
            <td><?php echo htmlspecialchars($row['vaccination_date']); ?></td>
            <td><?php echo htmlspecialchars($row['status']); ?></td>
        </tr>
        <?php } ?>
    </table>
</div>

<script>
function validateForm() {
    let vaccineName = document.getElementById("vaccine_name").value.trim();
    let vaccinationDate = document.getElementById("vaccination_date").value;
    let today = new Date().toISOString().split("T")[0];

    if (vaccineName === "" || vaccinationDate === "") {
        alert("⚠ Please fill in all fields!");
        return false;
    }

    if (vaccinationDate > today) {
        alert("⚠ Future vaccination dates are not allowed!");
        return false;
    }

    return true;
}
</script>

</body>
</html>
