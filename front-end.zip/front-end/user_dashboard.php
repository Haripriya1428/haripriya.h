<?php
session_start();
include 'config.php'; // Database connection

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch user's appointments
$sql = "SELECT pet_name, appointment_date FROM appointments WHERE user_id = ? ORDER BY appointment_date ASC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

?>
<!DOCTYPE html>
<html>
<head>
    <title>User Dashboard</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            color: #333;
            text-align: center;
            padding: 20px;
        }
        .container {
            width: 60%;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.2);
        }
        h2 {
            color: #4b0082;
        }
        a {
            display: inline-block;
            background: #ff0000;
            color: white;
            padding: 10px 15px;
            margin: 10px;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
        }
        a:hover {
            background: #cc0000;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }
        th {
            background: #4b0082;
            color: white;
        }
        td {
            background: #fafafa;
        }
    </style>
</head>
<body>
    <h2>Welcome, 
        <?php
        if (isset($_SESSION['user_name'])) {
            echo $_SESSION['user_name'];  // Display user name
        } else {
            echo "Guest";  // If user_name is not set
        }
        ?>
    </h2>
    <a href="add_appointment.php">Add Appointment</a> | <a href="userlogout.php">Logout</a>

    <h3>Your Appointments:</h3>
    <table border="1">
        <tr>
            <th>Pet Name</th>
            <th>Appointment Date</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()) { ?>
            <tr>
                <td><?php echo $row['pet_name']; ?></td>
                <td><?php echo $row['appointment_date']; ?></td>
            </tr>
        <?php } ?>
    </table>
</body>
</html>
